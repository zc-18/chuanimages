# attacker-idea

这是一个**极简攻击端 Maven 项目**，只做两件事：

1. 生成 `run\www\evil.jar`
2. 启动 `0.0.0.0:18181`，把这个 jar 提供出去

同时会顺手生成：

- `run\payload.json`

---

## 1. 用法

### IDEA
直接运行主类：

```text
com.example.fastjson2.attacker.AttackerApplication
```

### 命令行

```powershell
cd C:\Users\32768\Desktop\cua\2026-08-24-fastjson2-2.0.62分析\284mf0\MPS-rqng-2bko\attacker-idea
$env:JAVA_HOME='C:\Users\32768\Desktop\cua\2026-08-24-fastjson2-2.0.62分析\284mf0\MPS-rqng-2bko\tools\jdk8u504-b01'
$env:Path="$env:JAVA_HOME\bin;" + $env:Path
mvn.cmd -DskipTests package
java -jar .\target\attacker-idea-1.0-SNAPSHOT.jar
```

---

## 2. 必要设置

- **JDK 8**
- 端口固定 **18181**
- 当前 payload 固定命中 `localhost:18181`，**不要改端口**

推荐 JDK：

```text
C:\Users\32768\Desktop\cua\2026-08-24-fastjson2-2.0.62分析\284mf0\MPS-rqng-2bko\tools\jdk8u504-b01
```

---

## 3. 启动后你会得到

```text
run/
  payload.json
  www/
    evil.jar
```

控制台会打印：

- `TYPE_NAME`
- `PAYLOAD`
- `EVIL_JAR`
- `EXPECTED`
- `EXPECTED_HEX`
- `LISTEN`

---

## 4. 访问验证

攻击端健康检查：

```text
http://127.0.0.1:18181/health
```

返回：

```text
ok
```

---

## 5. 现在代码结构

只剩一个核心源码文件：

- `src\main\java\com\example\fastjson2\attacker\AttackerApplication.java`

里面已经包含：

- 生成恶意类
- 打包 evil.jar
- 生成 payload.json
- 启动 HTTP 服务
- 打印请求日志