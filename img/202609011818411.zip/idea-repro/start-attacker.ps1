param([int]$Port = 18181)
$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)
python -X utf8 .\poc\serve_evil.py $Port
