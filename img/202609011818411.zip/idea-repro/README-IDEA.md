# IDEA 手动启动版

## 先说结论
**不要直接用 IDEA 的 `Application` / `Spring Boot` 配置跑源码。**
这样通常是 `AppClassLoader`，不是本 PoC 依赖的 `LaunchedURLClassLoader`，复现大概率失败。

**正确方式：在 IDEA 里导入这个 Maven 工程，但运行时要启动打包后的 fat jar。**

## 目录
- `pom.xml`：源码工程
- `src/main/java`：已按 `biz-clean.jar` 还原
- `http/poc.http`：IDEA HTTP Client 可直接发包
- `start-attacker.ps1`：启动恶意 jar HTTP 服务
- `../poc/payload.json`：攻击 payload
- `../tools/jdk8u504-b01`：已准备好的 JDK 8

## IDEA 操作
### 1）导入工程
IDEA 打开目录：
`C:\Users\32768\Desktop\cua\2026-08-24-fastjson2-2.0.62分析\284mf0\MPS-rqng-2bko\idea-repro`

### 2）把 Maven/Project SDK 改成 JDK 8
使用：
`C:\Users\32768\Desktop\cua\2026-08-24-fastjson2-2.0.62分析\284mf0\MPS-rqng-2bko\tools\jdk8u504-b01`

### 3）先打包 fat jar
IDEA Maven 面板执行：
`Lifecycle -> package`

成功后生成：
`idea-repro\target\biz-clean.jar`

### 4）启动攻击端
方式 A：IDEA Terminal 里执行
```powershell
powershell -ExecutionPolicy Bypass -File .\start-attacker.ps1
```

看到监听 `18181` 即可。

### 5）在 IDEA 里手动启动目标
**推荐：新建 `JAR Application` 配置**
- JAR path: `...\idea-repro\target\biz-clean.jar`
- JRE: `...\tools\jdk8u504-b01`
- Working directory: `...\idea-repro\target`

然后点运行。

### 6）手动发请求
打开：
`idea-repro\http\poc.http`

按顺序点：
1. `GET /health`
2. `POST /parse`
3. `GET /marker`

## 成功标志
- `/health` 返回里有：
  - `jsonEngine=fastjson2`
  - `tccl=org.springframework.boot.loader.LaunchedURLClassLoader...`
- `/parse` 返回：`"ok": true`
- `/marker` 返回：`"exists": true`
- `idea-repro\target\pwned_remote.txt` 被写出

## 如果你非要用绿色三角直接跑源码
那是另一种运行形态，通常 **不会复现这个链**。
原因不是代码不对，而是 **ClassLoader 变了**。
