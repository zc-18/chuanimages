package com.example.biz;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

@RestController
public class ParseController {
    private static final String MARKER = "/tmp/pwned_remote";
    private static final String MARKER2 = "pwned_remote.txt";

    static boolean markerExists() {
        return new File(MARKER).exists() || new File(MARKER2).exists();
    }

    @GetMapping("/health")
    public Map<String, Object> health() {
        LinkedHashMap<String, Object> m = new LinkedHashMap<>();
        m.put("ok", true);
        m.put("role", "clean-business-target-fatjar");
        m.put("plantedMaliciousClass", false);
        m.put("pluginFilter", false);
        m.put("customClassLoader", false);
        m.put("tccl", String.valueOf(Thread.currentThread().getContextClassLoader()));
        m.put("markerExists", markerExists());
        m.put("jsonEngine", detectEngine());
        return m;
    }

    @GetMapping("/marker")
    public Map<String, Object> marker() {
        LinkedHashMap<String, Object> m = new LinkedHashMap<>();
        File f = new File(MARKER);
        if (!f.exists()) {
            f = new File(MARKER2);
        }
        m.put("exists", f.exists());
        if (f.exists()) {
            try (Scanner s = new Scanner(f, "UTF-8").useDelimiter("\\A")) {
                m.put("content", s.hasNext() ? s.next() : "");
            } catch (Exception e) {
                m.put("error", e.toString());
            }
        }
        return m;
    }

    @PostMapping(value = "/parse", consumes = {"application/json", "text/plain", "*/*"})
    public Map<String, Object> parse(@RequestBody String body) {
        LinkedHashMap<String, Object> resp = new LinkedHashMap<>();
        resp.put("tccl", String.valueOf(Thread.currentThread().getContextClassLoader()));
        try {
            Object obj = parseJson(body);
            resp.put("ok", true);
            resp.put("class", obj == null ? "null" : obj.getClass().getName());
            resp.put("loader", obj == null ? null : String.valueOf(obj.getClass().getClassLoader()));
            resp.put("markerExists", markerExists());
        } catch (Throwable t) {
            resp.put("ok", false);
            resp.put("error", t.getClass().getName() + ": " + t.getMessage());
            resp.put("markerExists", markerExists());
        }
        return resp;
    }

    static Object parseJson(String body) throws Exception {
        try {
            Class<?> c = Class.forName("com.alibaba.fastjson2.JSON");
            return c.getMethod("parseObject", String.class, Class.class).invoke(null, body, Object.class);
        } catch (ClassNotFoundException e) {
            Class<?> c = Class.forName("com.alibaba.fastjson.JSON");
            return c.getMethod("parse", String.class).invoke(null, body);
        }
    }

    static String detectEngine() {
        try {
            Class.forName("com.alibaba.fastjson2.JSON");
            return "fastjson2";
        } catch (ClassNotFoundException e) {
            try {
                Class.forName("com.alibaba.fastjson.JSON");
                return "fastjson1";
            } catch (ClassNotFoundException e2) {
                return "none";
            }
        }
    }
}
