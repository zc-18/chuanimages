package lab.fatjar.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.Arrays;

/**
 * 常规仿真环境配置。
 *
 * <p>不再注入 synthetic hash gate，也不再强制固定请求体；
 * 仅使用 Fastjson2 官方的 autoTypeFilter 做白名单仿真。</p>
 */
@Component
@ConfigurationProperties(prefix = "lab")
public class LabProperties {
    public static final String MARKER_PROPERTY = "FASTJSON2_DIRECT_FATJAR_MARKER";

    private final Artifact artifact = new Artifact();
    private final Fastjson2 fastjson2 = new Fastjson2();

    public Artifact getArtifact() {
        return artifact;
    }

    public Fastjson2 getFastjson2() {
        return fastjson2;
    }

    public String getTypeName() {
        return "jar:http:.." + artifact.getHost() + ":" + artifact.getPort()
                + "." + artifact.getPath() + "!.lab.Allowed.RemoteHarmless";
    }

    public String getRemoteUrl() {
        return "jar:http://" + artifact.getHost() + ":" + artifact.getPort()
                + "/" + artifact.getPath();
    }

    public String getSampleBody() {
        return "{\"c\":{\"@type\":\"" + getTypeName() + "\"}}";
    }

    public String[] getAutoTypeAcceptNames() {
        return Arrays.stream(fastjson2.getAutoTypeAcceptNames().split(","))
                .map(String::trim)
                .filter(value -> !value.isEmpty())
                .toArray(String[]::new);
    }

    public static class Artifact {
        private String host = "localhost";
        private int port = 19090;
        private String path = "safe";

        public String getHost() {
            return host;
        }

        public void setHost(String host) {
            this.host = host;
        }

        public int getPort() {
            return port;
        }

        public void setPort(int port) {
            this.port = port;
        }

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }
    }

    public static class Fastjson2 {
        private String autoTypeAcceptNames = "jar:http:..";

        public String getAutoTypeAcceptNames() {
            return autoTypeAcceptNames;
        }

        public void setAutoTypeAcceptNames(String autoTypeAcceptNames) {
            this.autoTypeAcceptNames = autoTypeAcceptNames;
        }
    }
}
