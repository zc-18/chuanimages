package lab.fatjar.controller;

import lab.fatjar.service.FastjsonParseService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/** MVC Controller：把 POST /parse 映射到解析 Service。 */
@RestController
@RequestMapping("/parse")
public class ParseController {
    private final FastjsonParseService parseService;

    public ParseController(FastjsonParseService parseService) {
        this.parseService = parseService;
    }

    @PostMapping
    public Map<String, Object> parse(@RequestBody String body) {
        return parseService.parse(body);
    }
}
