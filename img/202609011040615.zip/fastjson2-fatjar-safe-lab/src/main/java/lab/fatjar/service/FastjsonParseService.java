package lab.fatjar.service;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONException;
import com.alibaba.fastjson2.JSONReader;
import lab.fatjar.FatJarSafeApplication;
import lab.fatjar.config.LabProperties;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 常规 Fastjson2 解析服务。
 *
 * <p>这里直接走 Fastjson2 官方 API：
 * {@code JSONReader.autoTypeFilter(...)} + 标准 DTO 解析，
 * 不再注入反射门槛，不再限制固定请求体。</p>
 */
@Service
public class FastjsonParseService {
    private final LabProperties properties;
    private final ClassLoader applicationLoader;

    public FastjsonParseService(LabProperties properties) {
        this.properties = properties;
        this.applicationLoader = FatJarSafeApplication.class.getClassLoader();
    }

    public Map<String, Object> parse(String requestBody) {
        String body = requestBody == null ? "" : requestBody.trim();
        Map<String, Object> result = new LinkedHashMap<String, Object>();
        result.put("tccl", classLoaderName(Thread.currentThread().getContextClassLoader()));

        if (body.isEmpty()) {
            result.put("ok", false);
            result.put("error", "empty-request-body");
            return result;
        }

        try {
            JSONReader.AutoTypeBeforeHandler autoTypeFilter =
                    JSONReader.autoTypeFilter(properties.getAutoTypeAcceptNames());
            RequestBody parsed = JSON.parseObject(body, RequestBody.class, autoTypeFilter);
            Object remoteObject = parsed == null ? null : parsed.c;

            result.put("ok", true);
            if (remoteObject != null) {
                Class<?> remoteClass = remoteObject.getClass();
                result.put("remoteClass", remoteClass.getName());
                result.put("remoteClassLoader", classLoaderName(remoteClass.getClassLoader()));
            }

            String marker = System.getProperty(LabProperties.MARKER_PROPERTY);
            if (marker != null) {
                result.put("marker", marker);
            }
        } catch (Throwable ex) {
            fillError(result, ex);
        }

        return result;
    }

    private void fillError(Map<String, Object> result, Throwable ex) {
        Throwable root = rootCause(ex);
        String message = String.valueOf(root.getMessage());

        result.put("ok", false);
        if (isInvalidJson(root, message)) {
            result.put("error", "invalid-json");
            result.put("hint", properties.getSampleBody());
            return;
        }

        result.put("error", simpleName(root));
        if (message != null && !message.isEmpty() && !"null".equals(message)) {
            result.put("message", message);
        }
    }

    private static boolean isInvalidJson(Throwable root, String message) {
        return root instanceof JSONException
                && message != null
                && message.startsWith("illegal fieldName");
    }

    private static Throwable rootCause(Throwable ex) {
        Throwable current = ex;
        while (current.getCause() != null && current.getCause() != current) {
            current = current.getCause();
        }
        return current;
    }

    private static String simpleName(Throwable ex) {
        String simpleName = ex.getClass().getSimpleName();
        return simpleName == null || simpleName.isEmpty()
                ? ex.getClass().getName() : simpleName;
    }

    private static String classLoaderName(ClassLoader loader) {
        return loader == null ? "null" : loader.getClass().getName();
    }

    /**
     * 仍保留一个最小 DTO，模拟常见业务对象中的 Object 字段。
     */
    public static class RequestBody {
        public Object c;
    }
}
