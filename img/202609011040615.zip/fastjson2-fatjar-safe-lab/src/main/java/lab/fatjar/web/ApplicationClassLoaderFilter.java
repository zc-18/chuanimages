package lab.fatjar.web;

import lab.fatjar.FatJarSafeApplication;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 把请求线程 TCCL 临时切到 Spring Boot Fat JAR 的 LaunchedURLClassLoader。
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class ApplicationClassLoaderFilter extends OncePerRequestFilter {
    private final ClassLoader applicationLoader =
            FatJarSafeApplication.class.getClassLoader();

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {
        Thread thread = Thread.currentThread();
        ClassLoader previous = thread.getContextClassLoader();
        thread.setContextClassLoader(applicationLoader);
        try {
            filterChain.doFilter(request, response);
        } finally {
            thread.setContextClassLoader(previous);
        }
    }
}
