package lab.fatjar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Spring Boot 应用入口。
 *
 * <p>启动类只负责启动 Spring 容器，Controller、Service 和配置类由
 * Spring Boot 自动扫描和装配。</p>
 */
@SpringBootApplication
public class FatJarSafeApplication {
    public static void main(String[] args) {
        SpringApplication.run(FatJarSafeApplication.class, args);
    }
}
